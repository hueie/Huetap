var hueie = new Hueie();
function Hueie() {
}
Hueie.prototype.getEntries = function (start, callback) {
    console.log('Running getEntries');
    if (arguments.length === 1) callback = arguments[0];
    calendar.db.transaction(
        function (t) {
            t.executeSql('select id, info_0, info_1, info_2, info_3, info_4, info_5, info_6, reg_dt from calendar order by reg_dt desc', [],
                function (t, results) {
                    callback(calendar.fixResults(results));
                }, calendar.dbErrorHandler);
        }, calendar.dbErrorHandler);
};
Hueie.prototype.getEntry = function (reg_dt, callBack) {
    calendar.db.transaction(
        function (t) {
            t.executeSql('select id, info_0, info_1, info_2, info_3, info_4, info_5, info_6, reg_dt from calendar where reg_dt = ?', [reg_dt],
                function (t, results) {
                    if (results.rows.length == 0) return;
                    var tt = results.rows.item(0);
                    var result12 = {info_1: tt['info_1']};
                    callBack(results);
                }, calendar.dbErrorHandler);
        },
        calendar.dbErrorHandler, function () {
        });
};
Hueie.prototype.insertEntry = function (data, callback) {
    calendar.db.transaction(
        function (t) {
            t.executeSql(
                'insert into calendar(id,info_0,info_1,info_2,info_3,info_4,info_5,info_6,reg_dt) values(NULL,?, ?, ?, ?, ?, ?, ?, ?)',
                [data.info_0, data.info_1, data.info_2, data.info_3, data.info_4, data.info_5, data.info_6, data.reg_dt],
                function () {
                }, calendar.dbErrorHandler);
        },
        calendar.dbErrorHandler, callback);
};
Hueie.prototype.updateEntry = function (data, callback) {
    calendar.db.transaction(
        function (t) {
            t.executeSql(
                'update calendar set info_0=?,info_1=?,info_2=?,info_3=?,info_4=?,info_5=?,info_6=? where reg_dt = ?',
                [data.info_0, data.info_1, data.info_2, data.info_3, data.info_4, data.info_5, data.info_6, data.reg_dt],
                function (tx, rs) {
                }, calendar.dbErrorHandler);
        },
        calendar.dbErrorHandler, callback);
};
Hueie.prototype.checkDateData = function () {
    calendar.db.transaction(function (t) {
            t.executeSql('select id, info_0, info_1, info_2, info_3, info_4, info_5, info_6, reg_dt from calendar where reg_dt between ? and ? order by reg_dt asc', [startDate, endDate],
                function (t, ob) {

                }, null);
        },
        null);
}

Hueie.prototype.checkHueieData = function () {
    calendar.db.transaction(function (t) {
            t.executeSql('select id, info_0, info_1, reg_dt from calendar order by reg_dt asc', [],
                function (t, ob) {

                }, null);
        },
        null);
}


Hueie.prototype.inputDateData = function (pyy, pmm, pdd) {
    if (addEntryBtn1 == 1) {
        var sfmm = pmm;
        var sfdd = pdd;
        if (parseInt(pmm) < 10) {
            sfmm = "0" + pmm;
        }
        if (parseInt(pdd) < 10) {
            sfdd = "0" + pdd;
        }
        var reg_dt = pyy + "" + sfmm + "" + sfdd;

        var startCalRegDt = new Date(reg_dt.substring(0, 4), parseInt(reg_dt.substring(4, 6)) - 1, parseInt(reg_dt.substring(6, 8)) - 7);
        var endCalRegDt = new Date(reg_dt.substring(0, 4), parseInt(reg_dt.substring(4, 6)) - 1, parseInt(reg_dt.substring(6, 8)) + 7);

        var yy = startCalRegDt.getFullYear();
        var mm = startCalRegDt.getMonth() + 1;
        var dd = startCalRegDt.getDate();
        if (parseInt(mm) < 10) {
            mm = "0" + mm;
        }
        if (parseInt(dd) < 10) {
            dd = "0" + dd;
        }
        var startRegDt = yy + "" + mm + "" + dd;

        yy = endCalRegDt.getFullYear();
        mm = endCalRegDt.getMonth() + 1;
        dd = endCalRegDt.getDate();
        if (parseInt(mm) < 10) {
            mm = "0" + mm;
        }
        if (parseInt(dd) < 10) {
            dd = "0" + dd;
        }
        var endRegDt = yy + "" + mm + "" + dd;
        calendar.db.transaction(function (t) {
                t.executeSql('select id, info_0, info_1, info_2, info_3, info_4, info_5, info_6, reg_dt from calendar where reg_dt between ? and ?', [startRegDt, endRegDt],
                    function (t, ob) {

                    }, null);
            },
            null);
    }
}

Hueie.prototype.infoList = function () {
    calendar.db.transaction(function (t) {
            t.executeSql('select id, info_0, info_1, reg_dt from calendar order by reg_dt asc', [],
                function (t, ob) {
                    var content = "<div id='entryTable' style='color:"+themeColorDeep+";line-height: 2;'><table  width='100%' ><tbody>" +
                        "<tr style='height: "+infoTitleHeight+"px;font-size:"+infoTitleFontSize+"px;'><td colspan='4' style='line-height: 1;font-family: nanum-barun-gothic-bold;border: 1px solid "+themeColorDeep+";text-align: center;background-color:"+themeColorMain+";color: white;'><div class='think_white_icon' style='height:"+infoTitleFontSize+"px;width:"+infoTitleFontSize+"px;'></div><div style='display: inline-block;'>Check Check !!</div></td></tr>" +
                        "<tr style='height: "+infoListHeight+"px;font-size:"+infoListFontSize+"px;'><td colspan='4' style='text-align: center;'>If You Want To Have Your Calendars, </td></tr>"+
                        "<tr style='height: "+infoListHeight+"px;font-size:"+infoListFontSize+"px;'><td colspan='4' style='text-align: center;'>Do not Hesitate To Come Our Site </td></tr>" +
                        "<tr style='height: "+infoListHeight+"px;font-size:"+infoListFontSize+"px;'><td colspan='4' style='text-align: center;'>And Tell Me About Your Wish !</td></tr>" +
                        "<tr style='height: "+infoListHeight+"px;font-size:"+infoListFontSize+"px;'><td colspan='4' style='text-align: center;'><a  href='#' onclick='window.open(\"http://www.ysjoung.org\", \"_system\");' >Click It !!!</a></td></tr>" +
                        "<tr style='height: "+infoTitleHeight+"px;font-size: "+infoTitleFontSize+"px;'><td colspan='4' style='line-height: 1;font-family: nanum-barun-gothic-bold;border: 1px solid "+themeColorDeep+";text-align: center;background-color:"+themeColorMain+";color: white;'><div class='history_white_icon'></div><div style='display: inline-block; margin-left: 10px;'>Attribution</div></td></tr>" +
                        "</tbody></table>";

                    var contents =
                        "<tr style='height: "+infoListHeight+"px;font-size: "+infoListFontSize+"px;'><td colspan='2'  style='text-align: left;'>Icon made by <a title='Freepik' href='http://www.flaticon.com/authors/freepik'>Freepik</a> from <a title='Flaticon' href='http://www.flaticon.com'>www.flaticon.com</a>&nbsp;</td></tr>" +
                        "<tr style='height: "+infoListHeight+"px;font-size: "+infoListFontSize+"px;'><td colspan='2'  style='text-align: left;'>Icon made by <a title='Google' href='http://www.flaticon.com/authors/google'>Google</a> from <a title='Flaticon' href='http://www.flaticon.com'>www.flaticon.com</a>&nbsp;</td></tr>" +
                        "<tr style='height: "+infoListHeight+"px;font-size: "+infoListFontSize+"px;'><td colspan='2'  style='text-align: left;'>Icon made by <a title='Sean McCormick' href='http://www.flaticon.com/authors/sean-mccormick'>Sean McCormick</a> from <a title='Flaticon' href='http://www.flaticon.com'>www.flaticon.com</a>&nbsp;</td></tr>" +
                        "<tr style='height: "+infoListHeight+"px;font-size: "+infoListFontSize+"px;'><td colspan='2'  style='text-align: left;'>Icon made by <a title='OCHA' href='http://www.flaticon.com/authors/ocha'>OCHA</a> from <a title='Flaticon' href='http://www.flaticon.com'>www.flaticon.com</a>&nbsp;</td></tr>" +
                        "<tr style='height: "+infoListHeight+"px;font-size: "+infoListFontSize+"px;'><td colspan='2'  style='text-align: left;'>Icon made by <a title='Icon Works' href='http://www.flaticon.com/authors/icon-works'>Icon Works</a> from <a title='Flaticon' href='http://www.flaticon.com'>www.flaticon.com</a>&nbsp;</td></tr>" +
                        "<tr style='height: "+infoListHeight+"px;font-size: "+infoListFontSize+"px;'><td colspan='2'  style='text-align: left;'>Icon made by <a title='SimpleIcon' href='http://www.flaticon.com/authors/simpleicon'>SimpleIcon</a> from <a title='Flaticon' href='http://www.flaticon.com'>www.flaticon.com</a>&nbsp;</td></tr>" ;


                    var tmpHeight = (parseInt(totalHeight) - (noticHeight + calMenuHeight + mainMenuHeight + infoTitleHeight*2 + infoListHeight*4)) ;

                    content = content + "<div style='overflow:scroll; width:100%; height:" + tmpHeight + "px;'><table  width='100%' style='text-align: center;'><tbody>" +
                        ""+ contents + "" +
                        "</tbody></table></div></div>";
                    $('#entryTable').replaceWith(content);

                }, null);
        },
        null);
}