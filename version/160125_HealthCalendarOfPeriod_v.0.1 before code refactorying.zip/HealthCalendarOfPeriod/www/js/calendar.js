/**
 * Created by alpha on 2016-01-22.
 */
var pYear ;
var pMonth ;
var pDate ;
var pDay ;
var addEntryBtn1=1;

var startDate;
var endDate;

$(document).on("swipeRight", "#entryTable", function(e) {
    if (addEntryBtn1 == 1) {
        pMonth = pMonth - 1;
        if (pMonth == -1) {
            pMonth = 11;
            pYear = pYear - 1;
        }
        $('#year').text(pYear + ".");
        $('#month').text(parseInt(pMonth) + 1);
        $('#date').text("");
        $('#day').text("");
        changeCalendar(pYear,pMonth,pDate);

    } else if(addEntryBtn1==2){
        pYear = pYear - 1;
        $('#year').text(pYear);
        $('#month').text("");
        $('#date').text("");
        $('#day').text("");
        changeCalendar(pYear);
    }
});
$(document).on("swipeLeft", "#entryTable", function(e){
    if (addEntryBtn1 == 1) {
        pMonth = pMonth + 1;

        if (pMonth == 12) {
            pMonth = 0;
            pYear = pYear + 1;
        }

        $('#year').text(pYear + ".");
        $('#month').text(parseInt(pMonth) + 1);
        $('#date').text("");
        $('#day').text("");
        changeCalendar(pYear,pMonth,pDate);

    } else if(addEntryBtn1==2){
        pYear = pYear + 1;

        $('#year').text(pYear);
        $('#month').text("");
        $('#date').text("");
        $('#day').text("");
        changeCalendar(pYear);
    }
});
function yearToMonth(month){// 연도달력의 월을 클릭하면
    pMonth = month;
    addEntryBtn1=1;
    $('#year').text(pYear+".");
    $('#month').text(parseInt(pMonth)+1);
    $('#date').text("");
    $('#day').text("");
    changeCalendar(pYear,pMonth,pDate);

}

$(document).on("tap", "#addEntryBtn1", function(e) {
    //설정할 날짜 팝업
    opacity_bg_layer();
    var yContent = "";
    var mContent = "";
    for (var i = 0; i < 30; i++) {
        var tmp = pYear - 15 + i;
        yContent = yContent + "<option value='" + tmp + "'";
        if (tmp == pYear) {
            yContent = yContent + "selected='selected'";
        }
        yContent = yContent + ">" + tmp + "</option>";
    }
    for (var i = 0; i < 12; i++) {
        var tmp = i + 1;
        mContent = mContent + "<option value='" + tmp + "'";
        if (tmp - 1 == pMonth) {
            mContent = mContent + "selected='selected'";
        }
        mContent = mContent + ">" + tmp + "</option>";
    }
    var inputPopUp = "<div id='popup' class='pop_up_layer' style='background:white;'>" +
        "검색 날짜를 선택해주세요." +
        "<div>" +
        "<select name='sYear'>" + yContent + "</select>";
    if (addEntryBtn1 == 1) {
        inputPopUp = inputPopUp + "<select name='sMonth'>" + mContent + "</select>";
    }
    inputPopUp = inputPopUp + "<div>" +
        "<span><button onclick='pop_up_layer_close();layer_pop_close();'>취소</button></span>" +
        "<span><button onclick='selectSrchDate();pop_up_layer_close();layer_pop_close(); '>선택</button></span>" +
        "</div>" +
        "</div>" +
        "</div>";
    pop_up_layer(inputPopUp);
});
function selectSrchDate(){
    if (addEntryBtn1 == 1) {
        pYear = $('select[name=sYear]').val();
        pMonth =  $('select[name=sMonth]').val()-1;
        $('#year').text(pYear+".");
        $('#month').text(parseInt(pMonth)+1);
        $('#date').text("");
        $('#day').text("");
        changeCalendar(pYear,pMonth,pDate);

    } else{
        pYear = $('select[name=sYear]').val();
        $('#year').text(pYear);
        $('#month').text("");
        $('#date').text("");
        $('#day').text("");
        changeCalendar(pYear);
    }
}
$(document).on("tap", "#addEntryBtn2", function(e){
    $('#addEntryBtn1').css('display','block');
    addEntryBtn1=1;
    $('#year').text(pYear+".");
    $('#month').text(parseInt(pMonth)+1);
    $('#date').text("");
    $('#day').text("");
    changeCalendar(pYear,pMonth,pDate);

});
$(document).on("tap", "#addEntryBtn3", function(e){
    $('#addEntryBtn1').css('display','block');
    addEntryBtn1=2;
    $('#year').text(pYear);
    $('#month').text("");
    $('#date').text("");
    $('#day').text("");
    changeCalendar(pYear);
});

$(document).on("tap", "#addEntryBtn4", function(e){
    $('#addEntryBtn1').css('display','none');
    var today = new Date();
    var yy = today.getFullYear();
    var mm = today.getMonth()+1;
    var dd = today.getDate();
    var day = today.getDay();

    $('#year').text(yy+".");
    $('#month').text(mm+".");
    $('#date').text(dd);
    $('#day').text(strday(day,"kr"));
    var content="<table id='entryTable' border=1 width='100%'>" +
        "<tr><td colspan='4'> 평균생리 주기(최근 3회 기준)</td></tr>" +
        "<tr><td colspan='2'> 평균주기</td><td colspan='2'>평균 생리 기간</td></tr>" +
        "<tr><td colspan='4'>예정일</td></tr>" +
        "<tr><td colspan='2'> 생리 예정일</td><td colspan='2'>2016.02.15 D-25</td></tr>" +
        "<tr><td colspan='2'> 배란 예정일</td><td colspan='2'>2016.02.01 D-11</td></tr>" +
        "<tr><td colspan='2'> 확률높은 가임기</td><td colspan='2'>01.28~02.03</td></tr>" +
        "<tr><td colspan='4'>생리 히스토리</td></tr>" +
        "<tr ><td> 회차</td><td>시작일</td><td> 종료일</td><td> 주기</td></tr>" +
        "<tr ><td> 회차</td><td>시작일</td><td> 종료일</td><td> 주기</td></tr>" +
        "<tr ><td> 회차</td><td>시작일</td><td> 종료일</td><td> 주기</td></tr>" +
        "</table>";

    $('#entryTable').replaceWith(content);
});

function strday(day,lang) {
    if (lang == "kr") {
        switch (day) {
            case 0:
                return "일요일" ;
            case 1:
                return "월요일" ;
            case 2:
                return "화요일" ;
            case 3:
                return "수요일" ;
            case 4:
                return "목요일" ;
            case 5:
                return "금요일" ;
            case 6:
                return "터요일" ;
        }
    }
}

function makeMonthCalendar(pyy,pmm,pdd){
    var day = "<tr id='day'><td>일요일</td><td>월요일</td><td>화요일</td><td>수요일</td><td>목요일</td><td>금요일</td><td>토요일</td></tr>";

    var content = "<table id='entryTable' border=1 width='100%'>" +
        "<colgroup><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/></colgroup>"
        + day + makeCalendar(pyy,pmm,pdd) + "</table>";
    return content;
}
function makeYearCalendar(pyy){
    var calendars = "";
    for(var i=0; i<4 ;i++) {
        calendars = calendars +"<tr>";
        for (var j = 0; j < 3; j++) {
            var curMonth = i*3+j+1;
            var curMonthMinus = curMonth-1;
            calendars = calendars + "<td> " +
                "<a href='#' onclick='yearToMonth("+curMonthMinus+")' style='text-decoration : none;color:black;'>" +
                "<table id='entryInnerTable' border=0 style='font-size:2px;' ><span >"+curMonth+"</span>"+"월" +
                "<colgroup><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/></colgroup>"
                + makeBlankCalendar(pyy, curMonthMinus, 1) +
                "</table>" +
                "</a>" +
                "</td>";
        }
        calendars = calendars +"</tr>";
    }

    var content = "<table id='entryTable' border=1 width='100%'>" +
        "<colgroup><col width='33%'/><col width='33%'/><col width='33%'/></colgroup>"
        + calendars + "</table>";
    return content;
}

function makeCalendar(pyy, pmm, pdd){
    var today = new Date();
    today.setFullYear(pyy,pmm,pdd);
    var yy = today.getFullYear();
    var mm = today.getMonth()+1;
    var dd = today.getDate();
    var day = today.getDay();

    var minusWeekNum = parseInt(((dd - day)/7)+1);
    var strtdd = (dd - day - minusWeekNum*7);

    var firstDay = new Date();
    firstDay.setFullYear(yy, mm - 1, strtdd);

    var content = "";
    var style = "";
    for (var i = 0; i < 6; i++) {
        content = content + "<tr>";
        for (var j = 0; j < 7; j++) {
            var fyy = firstDay.getFullYear();
            var fmm = firstDay.getMonth() + 1;
            var fdd = firstDay.getDate();
            var str = "" + fyy + "," + fmm + "," + fdd;
            var sfmm = fmm;
            var sfdd = fdd;

            if (parseInt(fmm) < 10) {
                sfmm = "0" + fmm;
            }
            if (parseInt(fdd) < 10) {
                sfdd = "0" + fdd;
            }
            var reg_dt = fyy + "" + sfmm + "" + sfdd;
            if (i == 0 && j == 0) {
                startDate = reg_dt;
            } else if (i==5 && j==6){
                endDate = reg_dt;
            }

            if(firstDay.getMonth() == today.getMonth()){
                fdd = "<strong>" + fdd + "</strong>";
            }
            content = content + "<td id='"+reg_dt+"' name='caldate' ><a href='#' onclick='inputDateData("+str+")' style='text-decoration:none;color:black;'>" + fdd + "</a></td>";
            firstDay.setDate(firstDay.getDate()+ 1);
        }
        content = content + "</tr>";
    }
    return content;
}
function makeBlankCalendar(pyy, pmm, pdd){
    var today = new Date();
    today.setFullYear(pyy,pmm,pdd);
    var yy = today.getFullYear();
    var mm = today.getMonth()+1;
    var dd = today.getDate();
    var day = today.getDay();

    var minusWeekNum = parseInt(((dd - day)/7)+1);
    var strtdd = (dd - day - minusWeekNum*7);

    var firstDay = new Date();
    firstDay.setFullYear(yy, mm - 1, strtdd);
    startDate= yy+"0101";
    endDate=yy+"1231";

    var content = "";
    var style = "";
    for (var i = 0; i < 6; i++) {
        content = content + "<tr>";
        for (var j = 0; j < 7; j++) {
            if(firstDay.getMonth() == today.getMonth()){
            var fyy = firstDay.getFullYear();
            var fmm = firstDay.getMonth() + 1;
            var fdd = firstDay.getDate();
            var str = "" + fyy + "," + fmm + "," + fdd;
            var sfmm = fmm;
            var sfdd = fdd;

            if (parseInt(fmm) < 10) {
                sfmm = "0" + fmm;
            }
            if (parseInt(fdd) < 10) {
                sfdd = "0" + fdd;
            }
            var reg_dt = fyy + "" + sfmm + "" + sfdd;


            content = content + "<td id='"+reg_dt+"' name='caldate' ><a href='#' onclick='inputDateData("+str+")' style='text-decoration:none;color:black;'>" + fdd + "</a></td>";
            } else{
                content = content + "<td></td>"
            }

            firstDay.setDate(firstDay.getDate()+ 1);
        }
        content = content + "</tr>";
    }
    return content;
}


/*
function inputDateData(pyy,pmm,pdd) {
    if (addEntryBtn1 == 1) {
        var sfmm = pmm;
        var sfdd = pdd;
        if(parseInt(pmm)<10){
            sfmm = "0" + pmm;
        }
        if(parseInt(pdd)<10){
            sfdd = "0" + pdd;
        }
        opacity_bg_layer();
        var introPopUp = "<div id='popup' class='pop_up_layer' style='background:antiquewhite;'>" +
            "<form><table>" +
            "<tr><td colspan='2'><span> 선택 날짜 : " + pyy + "년" + pmm + "월" + pdd + "일" + "" +
            "<input type='hidden' id='reg_dt' value='"+pyy+sfmm+sfdd+"'></span>" +
            "<span><button id='addEntrySubmit'  >선택</button></span></td></tr>" +
            "<tr><td>생리일 : </td>" +
            "<td><input type='checkbox' id='info_0' >시작일</input>" +
            "<input type='checkbox' id='info_1' >종료일</input></td></tr>" +
            "<tr><td>사랑일(피임 X)  : </td><td><input type='checkbox' id='info_2'/></td></tr>" +
            "<tr><td>사랑일(피임 O)  : </td><td><input type='checkbox' id='info_3'/></td></tr>" +
            "<tr><td>피임약 복용  : </td><td><input type='checkbox' id='info_4'/></td></tr>" +
            "<tr><td>병원 진료일 : </td><td><input type='checkbox' id='info_5'/></td></tr>" +
            "<tr><td>기초체온 : </td><td><input type='text' id='info_6' value=''/></td></tr>" +
            "<tr><td>체중  : </td><td><input type='text' id='info_7' value=''/></td></tr>" +
            "<tr><td>노트  : </td><td><button onclick='pop_up_layer_close();layer_pop_close(); '>작성 하기 가기</button></td></tr>" +
            "</table> </form>" +
            " </div>";
        pop_up_layer(introPopUp);
        //selectSrchDate();
    }
}
*/
function inputDateData(pyy,pmm,pdd) {
    if (addEntryBtn1 == 1) {

        var sfmm = pmm;
        var sfdd = pdd;
        if(parseInt(pmm)<10){
            sfmm = "0" + pmm;
        }
        if(parseInt(pdd)<10){
            sfdd = "0" + pdd;
        }
        var reg_dt = pyy+""+sfmm+""+sfdd;
        var ddb = window.openDatabase("hcop", 1.0, "YoungSeok's Health Calendar Of Period", 5 * 1024 * 1024);
        ddb.transaction(function (t) {
            t.executeSql('select id, info_0, info_1, info_2, info_3, info_4, info_5, info_6, reg_dt from calendar where reg_dt = ?', [reg_dt],
                function (t, ob) {
                    var existed, info_0, info_1,info_2,info_3,info_4,info_5,info_6;
                    if(ob.rows.length == 0 ){

                    } else{
                        existed = 1;
                        if (parseInt(ob.rows.item(0)['info_0']) == 1) {
                            info_0 = "checked='true'";
                        }
                        if (parseInt(ob.rows.item(0)['info_1']) == 1) {
                            info_1 = "checked='true'";
                        }
                        if (parseInt(ob.rows.item(0)['info_2']) == 1) {
                            info_2 = "checked='true'";
                        }
                        if (parseInt(ob.rows.item(0)['info_3']) == 1) {
                            info_3 = "checked='true'";
                        }
                        if (parseInt(ob.rows.item(0)['info_4']) == 1) {
                            info_4 = "checked='true'";
                        }
                        if (parseInt(ob.rows.item(0)['info_5']) == 1) {
                            info_5 = "checked='true'";
                        }
                        if (parseInt(ob.rows.item(0)['info_6']) == 1) {
                            info_6 = "checked='true'";
                        }
                    }

            opacity_bg_layer();
            var introPopUp = "<div id='popup' class='pop_up_layer' style='background:antiquewhite;'>" +
                "<form>" +
                "<input type='hidden' id='existed' value='"+existed+"'>" +
                "<table>" +
                "<tr><td colspan='2'><span> 선택 날짜 : " + pyy + "년" + pmm + "월" + pdd + "일" + "" +
                "<input type='hidden' id='reg_dt' value='"+pyy+sfmm+sfdd+"'></span>" +
                "<span><button id='addEntrySubmit'  >선택</button></span></td></tr>" +
                "<tr><td>생리일 : </td>" +
                "<td><input type='checkbox' id='info_0' "+info_0+" >시작일</input>" +
                "<input type='checkbox' id='info_1' "+info_1+" >종료일</input></td></tr>" +
                "<tr><td>사랑일(피임 X)  : </td><td><input type='checkbox' id='info_2' "+info_2+"/></td></tr>" +
                "<tr><td>사랑일(피임 O)  : </td><td><input type='checkbox' id='info_3' "+info_3+"/></td></tr>" +
                "<tr><td>피임약 복용  : </td><td><input type='checkbox' id='info_4' "+info_4+"/></td></tr>" +
                "<tr><td>병원 진료일 : </td><td><input type='checkbox' id='info_5' "+info_5+"/></td></tr>" +
                "<tr><td>기초체온 : </td><td><input type='text' id='info_6' value='' "+info_6+"/></td></tr>" +
                "<tr><td>체중  : </td><td><input type='text' id='info_7' value=''/></td></tr>" +
                "<tr><td>노트  : </td><td><button onclick='pop_up_layer_close();layer_pop_close(); '>작성 하기 가기</button></td></tr>" +
                "</table> </form>" +
                " </div>";
            pop_up_layer(introPopUp);
            //selectSrchDate();



                } , null);
            },
            null);
    }
}

$(document).on("tap", "#addEntrySubmit", function(e) {
    //grab the values
    var info_0 = "0";
    var info_1 = "0";
    var info_2 = "0";//$("#info_2").val();
    var info_3 = "0";//$("#info_3").val();
    var info_4 = "0";//$("#info_4").val();
    var info_5 = "0";//$("#info_5").val();
    var info_6 = "0";//$("#info_6").val();
    var reg_dt = $("#reg_dt").val();

    if($("#info_0").prop('checked') == true){
        info_0 =1;
    }
    if($("#info_1").prop('checked') == true){
        info_1 =1;
    }
    if($("#info_2").prop('checked') == true){
        info_2 =1;
    }
    if($("#info_3").prop('checked') == true){
        info_3 =1;
    }
    if($("#info_4").prop('checked') == true){
        info_4 =1;
    }
    if($("#info_5").prop('checked') == true){
        info_5 =1;
    }
    if($("#info_6").prop('checked') == true){
        info_6 =1;
    }

    //store!
    if($("#existed").val() == 1){
        //$("#test").append('1234');
        calendar.updateEntry({info_0:info_0,info_1:info_1,info_2:info_2,info_3:info_3,info_4:info_4,info_5:info_5,info_6:info_6,reg_dt:reg_dt}, function() {
            pop_up_layer_close();
            layer_pop_close();
            pageLoad("calendar.html");
        });
    } else {
        calendar.insertEntry({info_0:info_0,info_1:info_1,info_2:info_2,info_3:info_3,info_4:info_4,info_5:info_5,info_6:info_6,reg_dt:reg_dt}, function() {
            pop_up_layer_close();
            layer_pop_close();
            pageLoad("calendar.html");
        });
    }



});