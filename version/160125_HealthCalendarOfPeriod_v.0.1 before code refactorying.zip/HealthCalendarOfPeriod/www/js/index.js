var calendar;
var appView;
var iOS = false;
var imgDir;
var notif=1;

var app = {
    initialize: function() {
        this.bindEvents();
    },
    bindEvents: function() {
        appView = $('#app');
        pageLoad("intro.html");
        var listeningElement = $('#listening2');
        var receivedElement = $('#received2');
        listeningElement.css('display','none');
        receivedElement.css('display','block');
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    onDeviceReady: function() {


        calendar = new Calendar();

        if(device.platform === "iOS") {
            iOS = true;
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0,
                function(fs) {
                    imgDir = fs.root;
                    calendar.setup(startApp);
                },
                null);
        } else {
            calendar.setup(startApp);
        }


//        app.receivedEvent('deviceready');
    },
    receivedEvent: function(id) {

    }
};

function startApp() {
    pageLoad("calendar.html");
}

function pageLoad(u) {
    console.log("load "+u);
    //convert url params into an ob
    var data = {};
    if(u.indexOf("?") >= 0) {
        var qs = u.split("?")[1];
        var parts = qs.split("&");
        for(var i=0, len=parts.length; i<len; i++) {
            var bits = parts[i].split("=");
            data[bits[0]] = bits[1];
        };
    }

    $.get(u,function(res,code) {
        appView.html(res);
        var evt = document.createEvent('CustomEvent');
        evt.initCustomEvent("pageload",true,true,data);
        var page = $("div", appView);
        page[0].dispatchEvent(evt);
    });
}

$(document).on("pageload", "#calendarPage", function(e) {
    addEntryBtn1=1;
    $('#year').text(pYear+".");
    $('#month').text(parseInt(pMonth)+1);
    $('#date').text("");
    $('#day').text("");
    changeCalendar(pYear,pMonth,pDate);

});
function changeCalendar(pYear,pMonth,pDate) {
    if (addEntryBtn1 == 1) {
        $('#entryTable').replaceWith(makeMonthCalendar(pYear, pMonth, pDate));
        checkDateData();
        checkPeriodData();
   } else if(addEntryBtn1==2) {
        $('#entryTable').replaceWith(makeYearCalendar(pYear));
        checkDateData();
        checkPeriodData();
    }

}
$(document).on("pageload", "#introPage", function(e) {
    var today = new Date();
    pYear = today.getFullYear();
    pMonth = today.getMonth();
    pDate = today.getDate();
    pDay = today.getDay();

    /*
    $('#year').text( pYear + ".");
    $('#month').text(parseInt(pMonth)+1);
    $('#date').text("");
    $('#day').text("");
    changeCalendar(pYear,pMonth,pDate);
    */
    opacity_bg_layer();
    var introPopUp = "<div id='popup' class='pop_up_layer' style='background:orange;'>" +
        "팝업의 내용입니다. 오늘의 공지사항 아이고 덥다" +
        "</div>";
    pop_up_layer(introPopUp);
});

$(document).on("pageload", "#magazinPage", function(e) {

});
$(document).on("pageload", "#mapPage", function(e) {

});
$(document).on("pageload", "#notePage", function(e) {

});
$(document).on("pageload", "#settingPage", function(e) {

});
$(document).on("pageload", "#notifPage", function(e) {

});

$(document).on('tap', '.opacity_bg_layer', function() { // 불투명 배경 레이어를 클릭하면 닫기
    pop_up_layer_close();
    layer_pop_close();
});
/* 공지사항 animate 로 위로 넘기기하려고 했음, 그러나 animate 함수 안먹힘, 급한 대로 interval 썼음
 $(document).on('tap', '#notification', function() {

 $("#notification").animate({rotate: '720deg', opacity: .5 }, 4, 'ease-out', function() {

 var content = "";
 if (notif == 1) {
 content = "<div id='notification' >Welcome to YS Joung Company.</div>";
 notif=2;
 } else if (notif == 2) {
 content = "<div id='notification'>PeriodCalendar : Notifications</div>";
 notif=1;
 }
 $("#notification").replaceWith(content);
 });
 });
 */
window.setInterval( function() {

    var content = "";
    if (notif == 1) {
        content = "<div id='notification' >Welcome to YS Joung Company.</div>";
        notif=2;
    } else if (notif == 2) {
        content = "<div id='notification'>PeriodCalendar : Notifications</div>";
        notif=1;
    }
    $("#notification").replaceWith(content);

}, 2000 );


/* 불투명 배경 레이어 뛰우기 */
function opacity_bg_layer() {
    // 화면의 가로, 세로 알아내기
    var w = $(document).width();
    var h = $(document).height();

    var layer = "<div class='opacity_bg_layer' ></div>";
    $('body').append(layer);

    var oj = $(".opacity_bg_layer");

    // 불투명 배경 레이어 크기 설정
    oj.css('width',w);
    oj.css('height',h);
    oj.css('display','block');
}
/* 레이어 닫기 */
function layer_pop_close() {
    if($('.opacity_bg_layer').length) { // 불투명 배경 레이어가 실행된 상태에서만 진행
        // 불투명 배경 레이어 삭제(속도:0.5초)
        var oj = $('.opacity_bg_layer');
        oj.remove();
    }
}
function pop_up_layer( content ) {
    // 화면의 가로, 세로 알아내기
    var w = $(document).width();
    var h = $(document).height();

    var layer = content;
    $('body').append(layer);

    var oj = $("#popup");

    top:0; left:0;
    // 불투명 배경 레이어 크기 설정
    oj.css('width',w*2/3);
    oj.css('height',h*2/3);
    oj.css('top',h/2);
    oj.css('left',w/6);


    oj.css('display','block');
}
/* 레이어 닫기 */
function pop_up_layer_close() {
    if($('#popup').length) { // 불투명 배경 레이어가 실행된 상태에서만 진행
        // 불투명 배경 레이어 삭제(속도:0.5초)
        var oj = $('#popup');
        oj.remove();
    }
}

