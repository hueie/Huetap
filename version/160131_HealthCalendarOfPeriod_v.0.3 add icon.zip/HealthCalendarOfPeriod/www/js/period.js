function checkDateData() {
    //var ddb = window.openDatabase("hcop", 1.0, "YoungSeok's Health Calendar Of Period", 5 * 1024 * 1024);
    calendar.db.transaction(function (t) {
            t.executeSql('select id, info_0, info_1, info_2, info_3, info_4, info_5, info_6, reg_dt from calendar where reg_dt between ? and ? order by reg_dt asc', [startDate, endDate],
                function (t, ob) {
                    var j = 0;
                    var checkPeriod;
                    if (addEntryBtn1 == 1) {
                        checkPeriod = 42;
                    } else if (addEntryBtn1 == 2) {
                        checkPeriod = 365
                    }
                    for (var i = 0; i < checkPeriod; i++) {
                        var target = $('td[name=caldate]').eq(i);//.child();
                        var curDate2 = target.prop('id');
                        if (curDate2 == ob.rows.item(j)['reg_dt']) {
                            if (addEntryBtn1 == 1) {
                                if (parseInt(ob.rows.item(j)['info_0']) == 1) {
                                    target.find('a').append('<div class=\"blood_start_deeppink_icon\"></div>');
                                }
                                if (parseInt(ob.rows.item(j)['info_1']) == 1) {
                                    target.find('a').append('<div class=\"blood_start_pink_icon\"></div>');
                                }
                                if (parseInt(ob.rows.item(j)['info_2']) == 1) {
                                    target.find('a').append('<div class=\"heart_pink_icon\"></div>');
                                }
                                if (parseInt(ob.rows.item(j)['info_3']) == 1) {
                                    target.find('a').append('<div class=\"condom_pink_icon\"></div>');
                                }
                                if (parseInt(ob.rows.item(j)['info_4']) == 1) {
                                    target.find('a').append('<div class=\"pill_pink_icon\"></div>');
                                }
                                if (parseInt(ob.rows.item(j)['info_5']) == 1) {
                                    target.find('a').append('<div class=\"hospital_pink_icon\"></div>');
                                }
                                if (parseInt(ob.rows.item(j)['info_6']) == 1) {
                                    target.css('background-color', '#gray');
                                }
                            }
                            if (addEntryBtn1 == 2) {
                                if (parseInt(ob.rows.item(j)['info_0']) == 1) {
                                    target.css('background-color', 'orange');
                                }
                                if (parseInt(ob.rows.item(j)['info_1']) == 1) {
                                    target.css('background-color', 'orange');
                                }
                                /*
                                if (parseInt(ob.rows.item(j)['info_2']) == 1) {
                                    //target.append('<div class=\"heart_pink_icon\"></div>');
                                    //target.css('background-color', 'red');
                                }
                                if (parseInt(ob.rows.item(j)['info_3']) == 1) {
                                    //target.append('<div class=\"condom_pink_icon\"></div>');
                                    //target.css('background-color', 'purple');
                                }
                                if (parseInt(ob.rows.item(j)['info_4']) == 1) {
                                    //target.append('<div class=\"pill_pink_icon\"></div>');
                                    //target.css('background-color', 'blue');
                                }
                                if (parseInt(ob.rows.item(j)['info_5']) == 1) {
                                    //target.append('<div class=\"hospital_pink_icon\"></div>');
                                    //target.css('background-color', 'green');
                                }
                                if (parseInt(ob.rows.item(j)['info_6']) == 1) {
                                    //target.css('background-color', '#gray');
                                }
                                */
                            }

                            j++;
                        }
                    }
                }, null);
        },
        null);
}
function checkPeriodData() {
    //var ddb = window.openDatabase("hcop", 1.0, "YoungSeok's Health Calendar Of Period", 5 * 1024 * 1024);
    calendar.db.transaction(function (t) {
            t.executeSql('select id, info_0, info_1, reg_dt from calendar order by reg_dt asc', [],
                function (t, ob) {
                    var target = $('td[name=caldate]');
                    var cYear = target.eq(0);
                    cYear = cYear.prop('id');
                    var calcYear = new Date(cYear.substring(0, 4), parseInt(cYear.substring(4, 6)) - 1, cYear.substring(6, 8));
                    var fYear = target.eq(-1);
                    fYear = fYear.prop('id');
                    var  calfYear = new Date(fYear.substring(0, 4), parseInt(fYear.substring(4, 6)) - 1, fYear.substring(6, 8));

                    var periodStart = "";
                    var periodEnd = "";
                    var calPeriodStart="";
                    var calPeriodEnd = "";
                    var calPrePeriodStart = new Date(1900, 1 - 1, 1);

                    var preAblePregnantStart = "";
                    var preAblePregnantEnd = "";
                    var ablePregnantStart = "";
                    var ablePregnantEnd = "";
                    var firstFlag =0;
                    for (var i = 0; i < ob.rows.length; i++) {
                        if (i > 0) {
                            var prePeriod = ob.rows.item(i - 1)['reg_dt'];
                            calPrePeriodStart  = new Date(prePeriod.substring(0, 4), parseInt(prePeriod.substring(4, 6)) - 1, prePeriod.substring(6, 8));
                        }
                        if (parseInt(ob.rows.item(i)['info_0']) == 1) {
                            periodStart = ob.rows.item(i)['reg_dt'];
                            //전의 가임기
                            preAblePregnantStart = new Date(periodStart.substring(0, 4), parseInt(periodStart.substring(4, 6)) - 1, parseInt(periodStart.substring(6, 8)) - 16);
                            preAblePregnantEnd = new Date(periodStart.substring(0, 4), parseInt(periodStart.substring(4, 6)) - 1, parseInt(periodStart.substring(6, 8)) - 10);
                            //후의 가임기
                            ablePregnantStart = new Date(periodStart.substring(0, 4), parseInt(periodStart.substring(4, 6)) - 1, parseInt(periodStart.substring(6, 8)) + 12);
                            ablePregnantEnd = new Date(periodStart.substring(0, 4), parseInt(periodStart.substring(4, 6)) - 1, parseInt(periodStart.substring(6, 8)) + 18);
                            //if (cYear <= ob.rows.item(i)['reg_dt'] && ob.rows.item(i)['reg_dt'] <= fYear) {
                                calPeriodStart = new Date(periodStart.substring(0, 4), parseInt(periodStart.substring(4, 6)) - 1, periodStart.substring(6, 8));
                            //} else {
                            //    periodStart = "";
                            //}
                        }
                        if (parseInt(ob.rows.item(i)['info_1']) == 1 && cYear <= ob.rows.item(i)['reg_dt'] && ob.rows.item(i)['reg_dt'] <= fYear) {
                            periodEnd = ob.rows.item(i)['reg_dt'];
                            calPeriodEnd = new Date(periodEnd.substring(0, 4), parseInt(periodEnd.substring(4, 6)) - 1, periodEnd.substring(6, 8));
                        }

                        //생리 시작일로 이전 가임기 색칠
                        if (calPeriodStart!="" && ( Math.abs(calPeriodStart - calPrePeriodStart) / constMilToAday > 60  )) {
                            if ((calcYear <= preAblePregnantStart && preAblePregnantEnd <= calfYear) || ( preAblePregnantStart <= calcYear && calcYear <= preAblePregnantEnd )|| (calfYear <= preAblePregnantEnd && preAblePregnantStart <= calfYear)) {
                                for (var j = Math.abs(preAblePregnantEnd - calcYear) / constMilToAday - 1; j > Math.abs(preAblePregnantEnd - calcYear) / constMilToAday - 7; j--) {
                                    if (0 <= j) {
                                        if (j == Math.abs(preAblePregnantEnd - calcYear) / constMilToAday - 4) {
                                            if (addEntryBtn1 == 1) {
                                                target.eq(j).find('a').append('<div class=\"big_ovum_deeppink_icon\"></div>');
                                            } else {
                                                target.eq(j).css('background-color', 'pink');
                                            }
                                        } else {
                                            if (addEntryBtn1 == 1) {
                                                target.eq(j).find('a').append('<div class=\"small_ovum_pink_icon\"></div>');
                                            } else {
                                                target.eq(j).css('background-color', 'pink');
                                            }
                                        }
                                    }
                                }
                                // 이전 생리 예정일 색칠
                                for (var j = (preAblePregnantEnd - calcYear) / constMilToAday - 8; j > (preAblePregnantEnd - calcYear) / constMilToAday - 14; j--) {
                                    if (0 <= j) {
                                        if (j == (preAblePregnantEnd - calcYear) / constMilToAday - 11) {
                                            if (addEntryBtn1 == 1) {
                                                target.eq(j).find('a').append('<div class=\"blood_start_blue_icon\"></div>');
                                            } else{
                                                target.eq(j).css('background-color', 'lightcyan');
                                            }
                                        } else {
                                            if (addEntryBtn1 == 1) {
                                                target.eq(j).find('a').append('<div class=\"blood_start_lightcyan_icon\"></div>');
                                            } else{
                                                target.eq(j).css('background-color', 'lightcyan');
                                            }
                                        }
                                    }
                                }
                                preAblePregnantEnd = "";
                            }
                        }
                        // 이후 가임기, 생리 예정일 색칠
                        if (ablePregnantStart != "") {
                            //if ((calcYear <= ablePregnantStart && ablePregnantEnd <= calfYear) || ( ablePregnantStart <= calfYear && calfYear <= ablePregnantEnd ) || ( ablePregnantStart <= calcYear && calcYear <= ablePregnantEnd   )) {
                                // 이후 가임기 색칠
                                for (var j = (ablePregnantStart - calcYear) / constMilToAday; j < (ablePregnantStart - calcYear) / constMilToAday + 6; j++) {
                                    if (0 <= j) {
                                        if (j == (ablePregnantStart - calcYear) / constMilToAday + 2) {
                                            if (addEntryBtn1 == 1) {
                                                target.eq(j).find('a').append('<div class=\"big_ovum_deeppink_icon\"></div>');
                                            } else{
                                                target.eq(j).css('background-color', 'pink');
                                            }
                                            //    target.eq(j).css('background-color', '#dfe3ee');
                                        } else {
                                            if (addEntryBtn1 == 1) {
                                                target.eq(j).find('a').append('<div class=\"small_ovum_pink_icon\"></div>');
                                            } else{
                                                target.eq(j).css('background-color', 'pink');
                                            }
                                        }
                                    }
                                }
                                // 이후 생리 예정일 색칠
                                for (var j = (ablePregnantStart - calcYear) / constMilToAday + 16; j < (ablePregnantStart - calcYear) / constMilToAday + 21; j++) {
                                    if (0 <= j) {
                                        if (j == (ablePregnantStart - calcYear) / constMilToAday+ 16) {
                                            if (addEntryBtn1 == 1) {

                                                target.eq(j).find('a').append('<div class=\"blood_start_blue_icon\"></div>');
                                            } else{
                                                target.eq(j).css('background-color', 'lightcyan');
                                            }
                                        } else {
                                            if (addEntryBtn1 == 1) {

                                                target.eq(j).find('a').append('<div class=\"blood_start_lightcyan_icon\"></div>');
                                            } else{
                                                target.eq(j).css('background-color', 'lightcyan');
                                            }
                                        }
                                    }
                                }
                                ablePregnantStart = "";
                            //}
                        }

                        //생리 기간 색칠
                        if (periodStart != "" && periodEnd != "") {
                            if (periodStart <= periodEnd) {
                                if (addEntryBtn1 == 1) {
                                    for (var j = Math.abs(calPeriodStart - calcYear) / constMilToAday + 1; j < Math.abs(calPeriodEnd - calcYear) / constMilToAday; j++) {
                                        //target.eq(j).css('background-color', 'red');
                                        target.eq(j).find('a').append('<div class=\"blood_start_pink_icon\"></div>');
                                    }
                                } else {
                                    for (var j = Math.abs(calPeriodStart - calcYear) / constMilToAday + 1; j < Math.abs(calPeriodEnd - calcYear) / constMilToAday; j++) {
                                        target.eq(j).css('background-color', 'orange');
                                    }
                                }
                                periodStart = "";
                                periodEnd = "";
                            } else if (periodStart > periodEnd) {
                                periodEnd = "";
                            }
                        }
                        else if (periodStart == "" && periodEnd != "") {
                            if (parseInt(i) != 0 && ob.rows.item(i - 1)['info_0'] == 1 && ob.rows.item(i - 1)['reg_dt'] < cYear) {
                                var prePeriodStart = ob.rows.item(i - 1)['reg_dt'];
                                if (prePeriodStart != "") {
                                    //처음까지색칠하기
                                    if (addEntryBtn1 == 1) {
                                        //생리기간 색칠
                                        for (var k = 0; k < Math.abs(calPeriodEnd - calcYear) / constMilToAday; k++) {
                                            target.eq(k).find('a').append('<div class=\"blood_start_pink_icon\"></div>');
                                        }
                                    } else {
                                        //생리기간 색칠
                                        for (var k = 0; k < Math.abs(calPeriodEnd - calcYear) / constMilToAday; k++) {
                                            target.eq(k).css('background-color', 'orange');
                                        }
                                    }
                                }
                            }
                            periodEnd = "";
                        }
                        else if (periodStart != "" && periodEnd == "") {
                            if (i != parseInt(ob.rows.length) - 1 && ob.rows.item(i + 1)['info_1'] == 1 && ob.rows.item(i + 1)['reg_dt'] > fYear) {
                                var prePeriodEnd = ob.rows.item(i + 1)['reg_dt'];
                                if (prePeriodEnd != "") {
                                    //끝까지색칠하기
                                    if (addEntryBtn1 == 1) {
                                        //생리기간 색칠
                                        for (var k = Math.abs(calPeriodStart - calcYear) / constMilToAday + 1; k < 42; k++) {
                                            target.eq(k).find('a').append('<div class=\"blood_start_pink_icon\"></div>');
                                        }
                                        //가임기간 색칠
                                    } else {
                                        //생리기간 색칠
                                        for (var k = Math.abs(calPeriodStart - calcYear) / constMilToAday + 1; k < 365; k++) {
                                            target.eq(k).css('background-color', 'orange');
                                        }
                                    }
                                }
                                periodStart = "";
                            }
                        }

                    }
                }, null);
        },
        null);
}
