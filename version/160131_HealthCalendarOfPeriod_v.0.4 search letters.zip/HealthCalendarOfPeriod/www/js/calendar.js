var totalHeight = $(window).height();

var calendar;

var pYear;
var pMonth;
var pDate;
var pDay;
var addEntryBtn1 = 1;

var startDate;
var endDate;
var constMilToAday = 24 * 60 * 60 * 1000;

function Calendar() {
    this.db = "";
}
Calendar.prototype.setup = function (callback) {
    this.db = window.openDatabase("hcop", 1.0, "YoungSeok's Health Calendar Of Period", 5 * 1024 * 1024);
    this.db.transaction(this.initDB, this.dbInitErrorHandler, callback);
};
Calendar.prototype.dbInitErrorHandler = function (e) {
    console.log('dbInitErrorHandlerr');
};
Calendar.prototype.dbErrorHandler = function (e) {
    if (e.code == 0) return;
    console.log('DB Error');
};
Calendar.prototype.initDB = function (t) {
    //t.executeSql('drop table calendar');
    //t.executeSql('drop table user');
    t.executeSql('create table if not exists user(id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
        'userinfo_0 TEXT, userinfo_1 TEXT, userinfo_2 TEXT, userinfo_3 TEXT, userinfo_4 TEXT, ' +
        'userinfo_5 TEXT, userinfo_6 TEXT, userinfo_7 TEXT, userinfo_8 TEXT, userinfo_9 TEXT, note TEXT, reg_dt TEXT)');
    t.executeSql('create table if not exists calendar(id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
        'info_0 TEXT, info_1 TEXT, info_2 TEXT, info_3 TEXT, info_4 TEXT, ' +
        'info_5 TEXT, info_6 TEXT, info_7 TEXT, info_8 TEXT, info_9 TEXT, note TEXT, reg_dt TEXT)');
};
Calendar.prototype.getEntries = function (start, callback) {
    console.log('Running getEntries');
    if (arguments.length === 1) callback = arguments[0];
    this.db.transaction(
        function (t) {
            t.executeSql('select id, info_0, info_1, info_2, info_3, info_4, info_5, info_6, reg_dt from calendar order by reg_dt desc', [],
                function (t, results) {
                    callback(this.fixResults(results));
                }, this.dbErrorHandler);
        }, this.dbErrorHandler);
};
Calendar.prototype.getEntry = function (reg_dt, callBack) {
    this.db.transaction(
        function (t) {
            t.executeSql('select id, info_0, info_1, info_2, info_3, info_4, info_5, info_6, reg_dt from calendar where reg_dt = ?', [reg_dt],
                function (t, results) {
                    if (results.rows.length == 0) return;
                    var tt = results.rows.item(0);
                    var result12 = {info_1: tt['info_1']};
                    callBack(results);

                }, this.dbErrorHandler);
        },
        this.dbErrorHandler, function () {
        });
};
Calendar.prototype.insertEntry = function (data, callback) {
    this.db.transaction(
        function (t) {
            t.executeSql(
                'insert into calendar(id,info_0,info_1,info_2,info_3,info_4,info_5,info_6,reg_dt) values(NULL,?, ?, ?, ?, ?, ?, ?, ?)',
                [data.info_0, data.info_1, data.info_2, data.info_3, data.info_4, data.info_5, data.info_6, data.reg_dt],
                function () {
                }, this.dbErrorHandler);
        },
        this.dbErrorHandler, callback);
};
Calendar.prototype.updateEntry = function (data, callback) {
    this.db.transaction(
        function (t) {
            t.executeSql(
                'update calendar set info_0=?,info_1=?,info_2=?,info_3=?,info_4=?,info_5=?,info_6=? where reg_dt = ?',
                [data.info_0, data.info_1, data.info_2, data.info_3, data.info_4, data.info_5, data.info_6, data.reg_dt],
                function (tx, rs) {
                }, this.dbErrorHandler);
        },
        this.dbErrorHandler, callback);
};
Calendar.prototype.fixResults = function (res) {
    var result = [];
    for (var i = 0, len = res.rows.length; i < len; i++) {
        var row = res.rows.item(i);
        result.push(row);
    }
    return result;
};
Calendar.prototype.fixResult = function (res) {
    if (res.rows.length) {
        return res.rows.item(0);
    } else {
        return res.rows.item(0);
    }
    ;
};
Calendar.prototype.yearToMonth = function (month) {// 연도달력의 월을 클릭하면
    pMonth = month;
    addEntryBtn1 = 1;
    setStringDateVar(pYear + ".", parseInt(pMonth) + 1, "", "");
    calendar.changeCalendar(pYear, pMonth, pDate);
};

Calendar.prototype.selectSrchDate = function () {
    if (addEntryBtn1 == 1) {
        pYear = parseInt($('select[name=sYear]').val());
        pMonth = parseInt($('select[name=sMonth]').val()) - 1;
        setStringDateVar(pYear + ".", parseInt(pMonth) + 1, "", "");
        calendar.changeCalendar(pYear, pMonth, pDate);

    } else {
        pYear = parseInt($('select[name=sYear]').val());
        setStringDateVar(pYear, "", "", "");
        calendar.changeCalendar(pYear);
    }
};
function strday(day, lang) {
    if (lang == "kr") {
        switch (day) {
            case 0:
                return "일";
            case 1:
                return "월";
            case 2:
                return "화";
            case 3:
                return "수";
            case 4:
                return "목";
            case 5:
                return "금";
            case 6:
                return "토";
        }
    }
}
//month calendar only have day
Calendar.prototype.makeMonthCalendar = function (pyy, pmm, pdd) {
    var tmpHeight = (parseInt(totalHeight) - 150) / 6;
    var day = "<tr id='day' style='height: 20px; font-size:15px;font-family: nanum-barun-gothic-bold;color: white;background-color:pink;'><td>일</td><td>월</td><td>화</td><td>수</td><td>목</td><td>금</td><td>토</td></tr>";
    var content = "<table  class='table ' id='entryTable' style='font-size:15px;text-align: left'><tbody>" +
        "<colgroup><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/></colgroup>"
        + day + calendar.makeCalendar(pyy, pmm, pdd) + "</tbody></table>";
    return content;
};
Calendar.prototype.makeYearCalendar = function (pyy) {
    var tmpHeight = (parseInt(totalHeight) - 220) / 4;
    var calendars = "";

    for (var i = 0; i < 4; i++) {
        calendars = calendars + "<tr style='height: " + tmpHeight + "px; '>";
        for (var j = 0; j < 3; j++) {
            var curMonth = i * 3 + j + 1;
            var curMonthMinus = curMonth - 1;
            calendars = calendars + "<td style='border: 1px solid ; border-color: pink;'> " +
                "<a href='#' onclick='calendar.yearToMonth(" + curMonthMinus + ")' style='text-decoration : none;color:black;'>" +
                //"<table  id='entryInnerTable' class='table' style='font-size:10px;padding:0;margin: 0;' ><div  style='text-align: center; display:inline-block; border: 1px solid deeppink; border-radius: 5px; width:20px; height:20px;font-size:15px;padding:0;margin: 2px;font-family: nanum-barun-gothic-bold;color: deeppink;'>" + curMonth + "</div>" +
                "<table  id='entryInnerTable' class='table' style='font-size:10px;padding:0;margin: 0;' ><div  style='text-align: center; display:inline-block; background-color: pink; width:100%; height:20px;font-size:15px;padding:0;margin: 0;font-family: nanum-barun-gothic-bold;color: white;'>" + curMonth + "</div>" +
                "<colgroup><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/><col width='14%'/></colgroup>"
                + calendar.makeBlankCalendar(pyy, curMonthMinus, 1)
                + "</table></a></td>";
        }
        calendars = calendars + "</tr>";
    }
    var content = "<table id='entryTable' class='table'  ><tbody><colgroup><col width='33%'/><col width='33%'/><col width='33%'/></colgroup>" + calendars + "</tbody></table>";
    return content;
};
Calendar.prototype.makeCalendar = function (pyy, pmm, pdd) {
    var today = new Date();//pdd
    today.setFullYear(pyy, pmm,1 );
    var yy = today.getFullYear();
    var mm = today.getMonth() + 1;
    var dd = today.getDate();
    var day = today.getDay();

    var minusWeekNum = parseInt(((dd - day) / 7) + 1);
    var strtdd = (dd - day - minusWeekNum * 7);
    var firstDay = new Date();
    firstDay.setFullYear(yy, mm - 1, strtdd);

    var content = "";
    var style = "";
    for (var i = 0; i < 6; i++) {
        content = content + "<tr style='padding: 0; margin: 0;'>";
        for (var j = 0; j < 7; j++) {
            var fontColor = "black";
            var fyy = firstDay.getFullYear();
            var fmm = firstDay.getMonth() + 1;
            var fdd = firstDay.getDate();
            var str = "" + fyy + "," + fmm + "," + fdd;
            var sfmm = fmm;
            var sfdd = fdd;
            if (parseInt(fmm) < 10) {
                sfmm = "0" + fmm;
            }
            if (parseInt(fdd) < 10) {
                sfdd = "0" + fdd;
            }
            var reg_dt = fyy + "" + sfmm + "" + sfdd;
            if (i == 0 && j == 0) {
                startDate = reg_dt;
            } else if (i == 5 && j == 6) {
                endDate = reg_dt;
            }
            if (firstDay.getMonth() == today.getMonth()) {
                fdd = "<strong>" + fdd + "</strong>";
            }
            if (j == 0) {
                fontColor = "red";
            } else if (j == 6) {
                fontColor = "blue";
            }


            var tmpHeight = (parseInt(totalHeight) - 150) / 6;

            content = content + "<td style='height: " + tmpHeight + "px;' id='" + reg_dt + "' name='caldate' ><a href='#' onclick='calendar.inputDateData(" + str + ")' style='width:100%; height: " + tmpHeight + "px;display:inline-block;text-decoration:none;color:" + fontColor + ";'>" + fdd + "</a></td>";
            firstDay.setDate(firstDay.getDate() + 1);
        }
        content = content + "</tr>";
    }
    return content;
};
Calendar.prototype.makeBlankCalendar = function (pyy, pmm, pdd) {
    var tmpHeight = (parseInt(totalHeight) - 220) / 24;

    var today = new Date();
    today.setFullYear(pyy, pmm, pdd);
    var yy = today.getFullYear();
    var mm = today.getMonth() + 1;
    var dd = today.getDate();
    var day = today.getDay();

    var minusWeekNum = parseInt(((dd - day) / 7) + 1);
    var strtdd = (dd - day - minusWeekNum * 7);
    var firstDay = new Date();
    firstDay.setFullYear(yy, mm - 1, strtdd);
    startDate = yy + "0101";
    endDate = yy + "1231";

    var content = "";
    var style = "";

    for (var i = 0; i < 6; i++) {
        content = content + "<tr style='height: " + tmpHeight + "px;'>";
        for (var j = 0; j < 7; j++) {
            if (firstDay.getMonth() == today.getMonth()) {
                var fontColor ="black";
                var fyy = firstDay.getFullYear();
                var fmm = firstDay.getMonth() + 1;
                var fdd = firstDay.getDate();
                var str = "" + fyy + "," + fmm + "," + fdd;
                var sfmm = fmm;
                var sfdd = fdd;

                if (parseInt(fmm) < 10) {
                    sfmm = "0" + fmm;
                }
                if (parseInt(fdd) < 10) {
                    sfdd = "0" + fdd;
                }


                if (firstDay.getMonth() == today.getMonth()) {
                    fdd = "<strong>" + fdd + "</strong>";
                }
                if (j == 0) {
                    fontColor = "red";
                } else if (j == 6) {
                    fontColor = "blue";
                }

                var reg_dt = fyy + "" + sfmm + "" + sfdd;
                content = content + "<td id='" + reg_dt + "' name='caldate' ><a href='#' onclick='calendar.inputDateData(" + str + ")' style='height: " + tmpHeight + "px;display:inline-block;text-decoration:none;color:" + fontColor + ";'>" + fdd + "</a></td>";
            } else {
                content = content + "<td></td>"
            }
            firstDay.setDate(firstDay.getDate() + 1);
        }
        content = content + "</tr>";
    }
    return content;
};
Calendar.prototype.changeCalendar = function (pYear, pMonth, pDate) {
    if (addEntryBtn1 == 1) {
        $('#entryTable').replaceWith(calendar.makeMonthCalendar(pYear, pMonth, pDate));
        checkDateData();
        checkPeriodData();
    } else if (addEntryBtn1 == 2) {
        $('#entryTable').replaceWith(calendar.makeYearCalendar(pYear));
        checkDateData();
        checkPeriodData();
    }
};
Calendar.prototype.inputDateData = function (pyy, pmm, pdd) {
    if (addEntryBtn1 == 1) {
        var sfmm = pmm;
        var sfdd = pdd;
        if (parseInt(pmm) < 10) {
            sfmm = "0" + pmm;
        }
        if (parseInt(pdd) < 10) {
            sfdd = "0" + pdd;
        }
        var reg_dt = pyy + "" + sfmm + "" + sfdd;
        calendar.db.transaction(function (t) {
                t.executeSql('select id, info_0, info_1, info_2, info_3, info_4, info_5, info_6, reg_dt from calendar where reg_dt = ?', [reg_dt],
                    function (t, ob) {
                        var existed, info_0, info_1, info_2, info_3, info_4, info_5, info_6;
                        if (ob.rows.length == 0) {

                        } else {
                            existed = 1;
                            if (parseInt(ob.rows.item(0)['info_0']) == 1) {
                                info_0 = "checked='true'";
                            }
                            if (parseInt(ob.rows.item(0)['info_1']) == 1) {
                                info_1 = "checked='true'";
                            }
                            if (parseInt(ob.rows.item(0)['info_2']) == 1) {
                                info_2 = "checked='true'";
                            }
                            if (parseInt(ob.rows.item(0)['info_3']) == 1) {
                                info_3 = "checked='true'";
                            }
                            if (parseInt(ob.rows.item(0)['info_4']) == 1) {
                                info_4 = "checked='true'";
                            }
                            if (parseInt(ob.rows.item(0)['info_5']) == 1) {
                                info_5 = "checked='true'";
                            }
                            if (parseInt(ob.rows.item(0)['info_6']) == 1) {
                                info_6 = "checked='true'";
                            }
                        }
                        var introPopUp = "<div id='popup' class='pop_up_layer' style='background:antiquewhite;border-radius: 25px;'>" +
                            "<div><form class='form-group'><div>" +
                            "<table class='table' style='color:deeppink;text-align: center;font-family: nanum-barun-gothic-bold;'>" +
                            "<input type='hidden' id='existed' value='" + existed + "'>" +
                            "<tr style='height: 50px;'><td colspan='2'><span style='font-size: 20px;'>" + pyy + ". " + pmm + ". " + pdd +"." +
                            "<input type='hidden' id='reg_dt' value='" + pyy + sfmm + sfdd + "'></span></td>" +
                            "<td colspan='2'><div class='greenCheck' id= 'addEntrySubmit'></div></td></tr>" +
                            "<tr  style='height: 50px;font-size: 20px;'><td colspan='2' width='50%'>생리일</td>" +
                            "<td colspan='2' width='50%' >" +
                            "<input class='startCheck' type='checkbox'  id='info_0' name='info_0'" + info_0 + " /><label for='info_0' ></label>" +
                            "<input class='endCheck' type='checkbox'  id='info_1' name='info_1'" + info_1 + " /><label for='info_1' ></label>" +
                            "</td></tr>" +
                            "<tr style='height: 50px;font-size: 20px;'><td colspan='2'>사랑일 (피임 X)</td>" +
                            "<td colspan='2'><input class='heartCheck' type='checkbox' class='checkbox' id='info_2' " + info_2 + "/><label for='info_2' ></label></td></tr>" +
                            "<tr style='height: 50px;font-size: 20px;'><td colspan='2'>사랑일 (피임 O)</td>" +
                            "<td colspan='2'><input class='heartblankCheck' type='checkbox' class='checkbox' id='info_3' " + info_3 + "/><label for='info_3' ></label></td></tr>" +
                            "<tr style='height: 50px;font-size: 20px;'><td colspan='2'>피임약 복용</td>" +
                            "<td colspan='2'><input class='pillCheck' type='checkbox' class='checkbox' id='info_4' " + info_4 + "/><label for='info_4' ></label></td></tr>" +
                            "<tr style='height: 50px;font-size: 20px;'><td colspan='2'>병원 진료일</td>" +
                            "<td colspan='2'><input class='hospitalCheck' type='checkbox' class='checkbox' id='info_5' " + info_5 + "/><label for='info_5' ></label></td></tr>" +
                            "<tr style='display:none;'><td>기초체온 : </td>" +
                            "<td><input type='hidden' id='info_6' value='' " + info_6 + "/></td></tr>" +
                            "<tr style='display:none;'><td>체중  : </td>" +
                            "<td><input type='hidden' id='info_7' value=''/></td></tr>" +
                            "<tr style='display:none;'><td>노트  : </td>" +
                            "<td><button onclick='pop_up_layer_close();layer_pop_close(); '>작성 하기 가기</button></td></tr>" +
                            "</table></div></form>" +
                            " </div></div>";
                        opacity_bg_layer();
                        pop_up_layer(introPopUp,screenWidth*5/6,300,screenWidth*1/12,(screenHeight-300)/2 );
                    }, null);
            },
            null);
    }
};
$(document).on("tap", "#addEntryBtn2", function (e) {
    $('#addEntryBtn1').css('display', 'inline-block');
    addEntryBtn1 = 1;
    setStringDateVar(pYear + ".", parseInt(pMonth) + 1, "", "");
    calendar.changeCalendar(pYear, pMonth, pDate);
});
$(document).on("tap", "#addEntryBtn3", function (e) {
    $('#addEntryBtn1').css('display', 'inline-block');
    addEntryBtn1 = 2;
    setStringDateVar(pYear, "", "", "");
    calendar.changeCalendar(pYear);
});
$(document).on("tap", "#addEntryBtn4", function (e) {
    $('#addEntryBtn1').css('display', 'none');
    var today = new Date();
    var yy = today.getFullYear();
    var mm = today.getMonth() + 1;
    var dd = today.getDate();
    var day = today.getDay();
    setStringDateVar(yy + ".", mm + ".", dd + ".", " " + strday(day, "kr"));

    if (addEntryBtn1 != 4) {
        addEntryBtn1 = 4;

        calendar.db.transaction(function (t) {
                t.executeSql('select id, info_0, info_1, reg_dt from calendar order by reg_dt desc', [],
                    function (t, ob) {
                        var today = new Date();
                        var prePeriodStart = "";
                        var periodStart = "";
                        var periodEnd = "";
                        var calPeriodStart = "";
                        var calPeriodEnd = "";
                        var calPrePeriodStart = "";

                        var ablePregnantStart = "";
                        var ablePregnantEnd = "";
                        var ablePregnantDay = "";
                        var nextPeriodStart = "";
                        var flag = "";
                        var cnt = 0;
                        var avgPeriod = 0; //평균 주기
                        var avgBleedingPeriod = 0; //평균 생리 기간
                        var contents = "";
                        var contentsPeriod = "";
                        var ccnt = 0;
                        for (var i = 0; i < ob.rows.length; i++) {
                            if (parseInt(ob.rows.item(i)['info_0']) == 1) {
                                periodStart = ob.rows.item(i)['reg_dt'];
                                calPeriodStart = new Date(periodStart.substring(0, 4), parseInt(periodStart.substring(4, 6)) - 1, parseInt(periodStart.substring(6, 8)));
                                if (flag == "") {
                                    //생리,배란 예정일
                                    nextPeriodStart = new Date(periodStart.substring(0, 4), parseInt(periodStart.substring(4, 6)) - 1, parseInt(periodStart.substring(6, 8)) + 18 + 14);

                                    ablePregnantStart = new Date(periodStart.substring(0, 4), parseInt(periodStart.substring(4, 6)) - 1, parseInt(periodStart.substring(6, 8)) + 12);
                                    ablePregnantDay = new Date(periodStart.substring(0, 4), parseInt(periodStart.substring(4, 6)) - 1, parseInt(periodStart.substring(6, 8)) + 14);
                                    ablePregnantEnd = new Date(periodStart.substring(0, 4), parseInt(periodStart.substring(4, 6)) - 1, parseInt(periodStart.substring(6, 8)) + 18);

                                    var dDay1 = Math.floor(Math.abs(nextPeriodStart - today) / constMilToAday);
                                    var dDay2 = Math.floor(Math.abs(ablePregnantDay - today) / constMilToAday);//가임기 시작일 +2일이 배란일
                                    flag = "true";
                                }
                            }
                            if (parseInt(ob.rows.item(i)['info_1']) == 1) {
                                periodEnd = ob.rows.item(i)['reg_dt'];
                                calPeriodEnd = new Date(periodEnd.substring(0, 4), parseInt(periodEnd.substring(4, 6)) - 1, parseInt(periodEnd.substring(6, 8)));
                            }

                            if (periodStart != "" && periodEnd != "" && periodEnd >= periodStart) {
                                if (cnt < 3) {
                                    avgBleedingPeriod = avgBleedingPeriod + Math.floor(Math.abs(calPeriodEnd - calPeriodStart) / constMilToAday);
                                    if (prePeriodStart != 0) {
                                        avgPeriod = avgPeriod + Math.floor(Math.abs(calPeriodStart - calPrePeriodStart) / constMilToAday)
                                    } else {
                                        calPrePeriodStart = calPeriodStart;
                                    }
                                } else if (cnt == 3) {
                                    avgBleedingPeriod = avgBleedingPeriod / 3;
                                    avgPeriod = avgPeriod / 2;
                                }

                                contentsPeriod = Math.floor(Math.abs(calPeriodStart - calPrePeriodStart) / constMilToAday);

                                if (ccnt == 0) {
                                    ccnt++;
                                } else {
                                    contents = contents + "</td><td>" + contentsPeriod + "</td></tr>";
                                }

                                contents = contents + "<tr style='height: 15px;' ><td >" + Math.floor((ob.rows.length - i) / 2 + 1) + "</td><td>" + calPeriodStart.getFullYear() + "." + (calPeriodStart.getMonth() + 1) + "." + calPeriodStart.getDate() + "</td><td>" +
                                    calPeriodEnd.getFullYear() + "." + (calPeriodEnd.getMonth() + 1) + "." + calPeriodEnd.getDate();

                                prePeriodStart = periodStart;
                                calPrePeriodStart = new Date(prePeriodStart.substring(0, 4), parseInt(prePeriodStart.substring(4, 6)) - 1, parseInt(prePeriodStart.substring(6, 8)));

                                cnt++;

                                periodStart = "";
                                periodEnd = "";
                            } else if (periodStart != "" && periodEnd != "" && periodEnd < periodStart) {
                                periodStart = "";
                            }
                        }
                        contents = contents + "</td><td>시작!</td></tr>";

                        var content = "<div id='entryTable' style='color:deeppink;line-height: 2;'><table  width='100%' ><tbody>" +
                            "<tr style='height: 15px;'><td colspan='4' style='line-height: 1;font-family: nanum-barun-gothic-bold;font-size: 30px; border: 1px solid deeppink;text-align: center;background-color:pink;color: white;'><div class='think_white_icon'></div><div style='display: inline-block;'>Check Check !!</div></td></tr>" +
                            "<tr style='height: 15px;'><td colspan='2' style='font-family: nanum-barun-gothic-bold;background-color: whitesmoke;'>평균 생리 주기" + "</td><td colspan='2' style='text-align: center;'>" + Math.floor(avgPeriod*10)/10 + " 일</td></tr>" +
                            "<tr style='height: 15px;'><td colspan='2' style='font-family: nanum-barun-gothic-bold;background-color: whitesmoke;'>평균 생리 기간" + "</td><td colspan='2' style='text-align: center;'>" + Math.floor(avgBleedingPeriod*10)/10 + " 일</td></tr>" +
                            "<tr style='height: 15px;'><td colspan='2' style='font-family: nanum-barun-gothic-bold;background-color: whitesmoke;'>생리 예정일</td><td colspan='1' style='text-align: center;'>" + nextPeriodStart.getFullYear() + "." + (nextPeriodStart.getMonth() + 1) + "." + nextPeriodStart.getDate() + "</td><td colspan='1' >" +"D -" + dDay1 + "</td></tr>" +
                            "<tr style='height: 15px;'><td colspan='2' style='font-family: nanum-barun-gothic-bold;background-color: whitesmoke;'>배란 예정일</td><td colspan='1' style='text-align: center;'>" + ablePregnantDay.getFullYear() + "." + (ablePregnantDay.getMonth() + 1) + "." + ablePregnantDay.getDate() + "</td><td colspan='1' >" +"D -" + dDay2 + "</td></tr>" +
                            "<tr style='height: 15px;'><td colspan='2' style='font-family: nanum-barun-gothic-bold;background-color: whitesmoke;'>확률높은 가임기</td><td colspan='2'  style='text-align: center;'>" + ablePregnantStart.getFullYear() + "." + (ablePregnantStart.getMonth() + 1) + "." + (ablePregnantStart.getDate()) + " ~ " + ablePregnantEnd.getFullYear() + "." + (ablePregnantEnd.getMonth() + 1) + "." + (ablePregnantEnd.getDate()) + "</td></tr>" +
                            "<tr style='height: 15px;'><td colspan='4' style='line-height: 1;font-family: nanum-barun-gothic-bold;font-size: 30px;border: 1px solid deeppink;text-align: center;background-color:pink;color: white;'><div class='history_white_icon'></div><div style='display: inline-block; margin-left: 10px;'>HISTORY ~</div></td></tr>" +
                            "</tbody></table>";

                        var tmpHeight = (parseInt(totalHeight) - 280);

                        content = content + "<div style='overflow:scroll; width:100%; height:" + tmpHeight + "px;'><table  width='100%' style='text-align: center;'><tbody>" +
                            "<tr style='height: 15px;font-family: nanum-barun-gothic-bold;background-color: whitesmoke;'><td> 회차</td><td>시작일</td><td> 종료일</td><td> 주기</td></tr>" +
                            contents +
                            "</tbody></table></div></div>";


                        $('#entryTable').replaceWith(content);
                    }, null);
            },
            null);
    }
});
$(document).on("tap", "#addEntrySubmit", function (e) {
    //grab the values
    var info_0 = "0";
    var info_1 = "0";
    var info_2 = "0";//$("#info_2").val();
    var info_3 = "0";//$("#info_3").val();
    var info_4 = "0";//$("#info_4").val();
    var info_5 = "0";//$("#info_5").val();
    var info_6 = "0";//$("#info_6").val();
    var reg_dt = $("#reg_dt").val();
    if ($("#info_0").prop('checked') == true) {
        info_0 = 1;
    }
    if ($("#info_1").prop('checked') == true) {
        info_1 = 1;
    }
    if ($("#info_2").prop('checked') == true) {
        info_2 = 1;
    }
    if ($("#info_3").prop('checked') == true) {
        info_3 = 1;
    }
    if ($("#info_4").prop('checked') == true) {
        info_4 = 1;
    }
    if ($("#info_5").prop('checked') == true) {
        info_5 = 1;
    }
    if ($("#info_6").prop('checked') == true) {
        info_6 = 1;
    }
    //store!
    if ($("#existed").val() == 1) {
        calendar.updateEntry({
            info_0: info_0,
            info_1: info_1,
            info_2: info_2,
            info_3: info_3,
            info_4: info_4,
            info_5: info_5,
            info_6: info_6,
            reg_dt: reg_dt
        }, function () {
            pop_up_layer_close();
            layer_pop_close();
            pageLoad("calendar.html");
        });
    } else {
        calendar.insertEntry({
            info_0: info_0,
            info_1: info_1,
            info_2: info_2,
            info_3: info_3,
            info_4: info_4,
            info_5: info_5,
            info_6: info_6,
            reg_dt: reg_dt
        }, function () {
            pop_up_layer_close();
            layer_pop_close();
            pageLoad("calendar.html");
        });
    }
});

$(document).on("swipeRight", "#entryTable", function (e) {
    if (addEntryBtn1 == 1) {
        pMonth = pMonth - 1;
        if (pMonth == -1) {
            pMonth = 11;
            pYear = pYear - 1;
        }
        setStringDateVar(pYear + ".", parseInt(pMonth) + 1, "", "");
        calendar.changeCalendar(pYear, pMonth, pDate);
    } else if (addEntryBtn1 == 2) {
        pYear = pYear - 1;
        setStringDateVar(pYear, "", "", "");
        calendar.changeCalendar(pYear);
    }
});
$(document).on("swipeLeft", "#entryTable", function (e) {
    if (addEntryBtn1 == 1) {
        pMonth = pMonth + 1;
        if (pMonth == 12) {
            pMonth = 0;
            pYear = pYear + 1;
        }
        setStringDateVar(pYear + ".", parseInt(pMonth) + 1, "", "");
        calendar.changeCalendar(pYear, pMonth, pDate);
    } else if (addEntryBtn1 == 2) {
        pYear = pYear + 1;
        setStringDateVar(pYear, "", "", "");
        calendar.changeCalendar(pYear);
    }
});

//검색 할 날짜 팝업
$(document).on("tap", "#addEntryBtn1", function (e) {
    var yContent = "";
    var mContent = "";
    for (var i = 0; i < 30; i++) {
        var tmp = pYear - 15 + i;
        yContent = yContent + "<option value='" + tmp + "'";
        if (tmp == pYear) {
            yContent = yContent + "selected='selected'";
        }
        yContent = yContent + ">" + tmp + "</option>";
    }
    for (var i = 0; i < 12; i++) {
        var tmp = i + 1;
        mContent = mContent + "<option value='" + tmp + "'";
        if (tmp - 1 == pMonth) {
            mContent = mContent + "selected='selected'";
        }
        mContent = mContent + ">" + tmp + "</option>";
    }

    var inputPopUp = "<div id='popup' class='pop_up_layer' style='color:hotpink;background-color: antiquewhite;border-radius: 15px;font-family: nanum-barun-gothic-bold;'>" +
        "<table width='100%' style='margin-top: 10px; text-align: center;border-color: pink'>" ;
    if (addEntryBtn1 == 1) {
        inputPopUp = inputPopUp + "<tr >" +
            "<td  style='height:20px;'>" +
            "<select name='sYear' style='height:100%;font-size:20px;text-align: center;'>" + yContent + "</select>" +
            "</td>"+
            "<td >" +
            "<select name='sMonth' style='height:100%;font-size:20px;'>" + mContent + "</select>" +
            "</td>" ;
    }
    if (addEntryBtn1 == 2) {
        inputPopUp = inputPopUp + "<tr >" +
            "<td  style='height:20px;'>" +
            "<select name='sYear' style='height:100%;font-size:20px;text-align: center;'>" + yContent + "</select>" +
            "</td>" ;
    }
    inputPopUp = inputPopUp +
        "<td><a style='display:inline-block;height:100%;' onclick='calendar.selectSrchDate();pop_up_layer_close();layer_pop_close(); '><div class='greenCheck'></div></a></td>" +
        "</tr>" +
        "</table></div>" ;

    /*
    var inputPopUp = "<div id='popup' class='pop_up_layer' style='color:hotpink;background-color: antiquewhite;border-radius: 25px;font-family: nanum-barun-gothic-bold;'><table width='100%' style='text-align: center;border-color: pink'>" +
        "<tr ><td colspan='2' style='padding: 10px;height:100%;font-size: 20px'>검색할  날짜를 선택하세요.</td></tr>" ;
    if (addEntryBtn1 == 1) {
        inputPopUp = inputPopUp + "<tr >" +
            "<td width='50%' style='height:20px;'>" +
            "<select name='sYear' style='height:100%;font-size:20px;text-align: center;'>" + yContent + "</select>" +
            "</td>"+
            "<td width='50%'>" +
            "<select name='sMonth' style='height:100%;font-size:20px;'>" + mContent + "</select>" +
            "</td>" +
            "</tr>";
    }
    if (addEntryBtn1 == 2) {
        inputPopUp = inputPopUp + "<tr >" +
            "<td colspan='2' width='100%' style='height:20px;'>" +
        "<select name='sYear' style='height:100%;font-size:20px;text-align: center;'>" + yContent + "</select>" +
            "</td>" +
            "</tr>";
    }
    inputPopUp = inputPopUp +
        "<tr style='height:20px;'>" +
        "<td><a style='display:inline-block;width:100%;height:100%;' onclick='pop_up_layer_close();layer_pop_close();'><div class='redCheck'></div></a></td>" +
        "<td><a style='display:inline-block;width:100%;height:100%;' onclick='calendar.selectSrchDate();pop_up_layer_close();layer_pop_close(); '><div class='whiteblueCheck'></div></a></td>" +
        "</tr>" +
        "</table></div>" ;
        */
    opacity_bg_layer();
    pop_up_layer(inputPopUp, screenWidth*2/3, 60, screenWidth/6,(screenHeight-60)/2);
});