var appView;
var iOS = false;
var imgDir;
var notif;
var pFooter =1;

var app = {
    initialize: function() {
        this.bindEvents();
    },
    bindEvents: function() {
        appView = $('#app');
        pageLoad("intro.html");
        var listeningElement = $('#listening2');
        var receivedElement = $('#received2');
        listeningElement.css('display','none');
        receivedElement.css('display','block');
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    onDeviceReady: function() {
        notif=1;
        setGlobalVar(1);
        calendar = new Calendar();
        if(device.platform === "iOS") {
            iOS = true;
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0,
                function(fs) {
                    imgDir = fs.root;
                    calendar.setup(startApp);
                },
                null);
        } else {
            calendar.setup(startApp);
        }
    },
    receivedEvent: function(id) {
    }
};
function startApp() {
    pageLoad("calendar.html");
}
function setGlobalVar(_addEntryBtn1){
    if(_addEntryBtn1 != null){
        addEntryBtn1 = _addEntryBtn1;
    }
}
function setGlobalDateVar(_year, _month, _date, _day){
    if(_year != null){
        pYear = _year;
    }
    if(_month != null){
        pMonth = _month;
    }
    if(_date != null){
        pDate = _date;
    }
    if(_day != null){
        pDay = _day;
    }
}
function setStringDateVar(_year, _month, _date, _day){
    if(_year != null){
        $('#year').text(_year);
    }
    if(_month != null){
        $('#month').text(_month);
    }
    if(_date != null){
        $('#date').text(_date);
    }
    if(_day != null){
        $('#day').text(_day);
    }
}
$(document).on("pageload", "#calendarPage", function(e) {
    setGlobalVar(1);
    setStringDateVar(pYear+".", parseInt(pMonth)+1, "","");
    calendar.changeCalendar(pYear,pMonth,pDate);
});
window.setInterval( function() {
    var content = "";
    switch (notif){
        case 1 :
            content = "<a id='notification' class='col-sx-12' href='#' onclick='window.open(\"http://www.ysjoung.org\", \"_system\");' >Go To YS Joung Company !!!</a>";
            notif=2;
            break;
        case 2 :
            content = "<a id='notification' class='col-sx-12' href='#' onclick='window.open(\"http://www.ysjoung.org\", \"_system\");' >Click Get Some Calendars Of Your Own !!!</a>";
            notif=1;
            break;
    }
    $("#notification").replaceWith(content);
}, 2000 );
$(document).on("pageload", "#introPage", function(e) {
    var today = new Date();
    setGlobalDateVar(today.getFullYear(), today.getMonth(),today.getDate(), today.getDay());
    var introPopUp = "<div id='popup' class='pop_up_layer' style='background:orange;'>" +
        "팝업의 내용입니다. 오늘의 공지사항 입니다." +
        "</div>";
    //opacity_bg_layer();
    //pop_up_layer(introPopUp);
});
$(document).on("pageload", "#magazinPage", function(e) {
});
$(document).on("pageload", "#mapPage", function(e) {
});
$(document).on("pageload", "#notePage", function(e) {
});
$(document).on("pageload", "#settingPage", function(e) {
});
$(document).on("pageload", "#notifPage", function(e) {
});

function update(){
    var contents ="";
    contents = "<div id='popup' class='pop_up_layer' style='text-align:center;border-radius: 25px;background:lightgoldenrodyellow;font-family: nanum-barun-gothic-bold;font-size: 15px;color: hotpink'>";
    contents = contents + "<div style='padding-top:"+screenHeight/12+"px; vertical-align:middle; border-radius: 25px;border: 1px;'>업데이트할 예정입니다. <br> 아래 링크에 의견을 남겨주시면 <br> 적극 반영하겠습니다. ^^<br><br>" +
        "<a href='#' style='text-decoration : none;color:steelblue;' onclick='window.open(\"http://www.ysjoung.org\", \"_system\");' >Go To YS Joung Company !!!</a>";
    contents = contents + "</div></div>";
    opacity_bg_layer();
    pop_up_layer(contents, screenWidth*2/3, screenHeight/3, screenWidth/6,screenHeight/3);
}

$(document).on("swipeLeft", "#footer", function (e) {
    if (pFooter == 1) {
        var contents ="";
        contents = contents + "<table id='footerTable' width='100%' style='padding: 0; margin: 0;'><tr style='height: 70px;'>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: red' id='addMenuBtn8' onclick='update()'><div class='bloodsugar_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: saddlebrown' id='addMenuBtn9' onclick='update()'><div class='map_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: black' id='addMenuBtn10' onclick='update()'><div class='gentleman_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: sandybrown' id='addMenuBtn11' onclick='update()'><div class='wheat_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: lightskyblue' id='addMenuBtn11' onclick='update()'><div class='airplane_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: yellowgreen' id='addMenuBtn11' onclick='update()'><div class='study_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: aquamarine' id='addMenuBtn11' onclick='update()'><div class='travel_icon'></div></a></td>"+
            "</tr>"+
            "</table>";
        pFooter=2;
        $('#footerTable').replaceWith(contents);
    }else if (pFooter == 2) {
        var contents ="";
        contents = contents + "<table id='footerTable' width='100%' style='padding: 0; margin: 0;'><tr style='height: 70px;'>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: pink' id='addMenuBtn1' onclick='pageLoad(\"calendar.html\")'><div class='period_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: hotpink' id='addMenuBtn2' onclick='update()'><div class='pregnant_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: navajowhite' id='addMenuBtn3' onclick='update()'><div class='baby_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: greenyellow' id='addMenuBtn4' onclick='update()'><div class='budding_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: gold' id='addMenuBtn5' onclick='update()'><div class='finance_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: slategray' id='addMenuBtn6' onclick='update()'><div class='muscle_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: silver' id='addMenuBtn7' onclick='update()'><div class='setting_icon'></div></a></td>"+
            "</tr>"+
            "</table>";
        pFooter=1;
        $('#footerTable').replaceWith(contents);
    }
});

$(document).on("swipeRight", "#footer", function (e) {
    if (pFooter == 1) {
        var contents ="";
        contents = contents + "<table id='footerTable' width='100%' style='padding: 0; margin: 0;'><tr style='height: 70px;'>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: red' id='addMenuBtn8' onclick='update()'><div class='bloodsugar_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: saddlebrown' id='addMenuBtn9' onclick='update()'><div class='map_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: black' id='addMenuBtn10' onclick='update()'><div class='gentleman_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: sandybrown' id='addMenuBtn11' onclick='update()'><div class='wheat_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: lightskyblue' id='addMenuBtn11' onclick='update()'><div class='airplane_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: yellowgreen' id='addMenuBtn11' onclick='update()'><div class='study_icon'></div></a></td>"+
            "<td width='50px' ><a class='mainMenu' style=' background-color: aquamarine' id='addMenuBtn11' onclick='update()'><div class='travel_icon'></div></a></td>"+
            "</tr>"+
            "</table>";
        pFooter=2;
        $('#footerTable').replaceWith(contents);
    }else if (pFooter == 2) {
        var contents ="";
        contents = contents + "<table id='footerTable' width='100%' style='padding: 0; margin: 0;'><tr style='height: 70px;'>"+
        "<td width='50px' ><a class='mainMenu' style=' background-color: pink' id='addMenuBtn1' onclick='pageLoad(\"calendar.html\")'><div class='period_icon'></div></a></td>"+
        "<td width='50px' ><a class='mainMenu' style=' background-color: hotpink' id='addMenuBtn2' onclick='update()'><div class='pregnant_icon'></div></a></td>"+
        "<td width='50px' ><a class='mainMenu' style=' background-color: navajowhite' id='addMenuBtn3' onclick='update()'><div class='baby_icon'></div></a></td>"+
        "<td width='50px' ><a class='mainMenu' style=' background-color: greenyellow' id='addMenuBtn4' onclick='update()'><div class='budding_icon'></div></a></td>"+
        "<td width='50px' ><a class='mainMenu' style=' background-color: gold' id='addMenuBtn5' onclick='update()'><div class='finance_icon'></div></a></td>"+
        "<td width='50px' ><a class='mainMenu' style=' background-color: slategray' id='addMenuBtn6' onclick='update()'><div class='muscle_icon'></div></a></td>"+
        "<td width='50px' ><a class='mainMenu' style=' background-color: silver' id='addMenuBtn7' onclick='update()'><div class='setting_icon'></div></a></td>"+
            "</tr>"+
            "</table>";
        pFooter=1;
        $('#footerTable').replaceWith(contents);
    }
});
