var appView;
var iOS = false;
var imgDir;
var notif=1;

var app = {
    initialize: function() {
        this.bindEvents();
    },
    bindEvents: function() {
        appView = $('#app');
        pageLoad("intro.html");
        var listeningElement = $('#listening2');
        var receivedElement = $('#received2');
        listeningElement.css('display','none');
        receivedElement.css('display','block');
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    onDeviceReady: function() {
        calendar = new Calendar();
        if(device.platform === "iOS") {
            iOS = true;
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0,
                function(fs) {
                    imgDir = fs.root;
                    calendar.setup(startApp);
                },
                null);
        } else {
            calendar.setup(startApp);
        }
    },
    receivedEvent: function(id) {
    }
};
function startApp() {
    pageLoad("calendar.html");
}
function setGlobalVar(_addEntryBtn1, _pYear, _pMonth, _pDate, _pDay){
    if(_addEntryBtn1 != null){
        addEntryBtn1 = _addEntryBtn1;
    }
    if(_pYear != null){
        pYear = _pYear;
    }
    if(_pMonth != null){
        pMonth = _pMonth;
    }
    if(_pDate != null){
        pDate = _pDate;
    }
    if(_pDay != null){
        pDay = _pDay;
    }
}
function setStringVar(_year, _month, _date, _day){
    if(_year != null){
        $('#year').text(_year);
    }
    if(_month != null){
        $('#month').text(_month);
    }
    if(_date != null){
        $('#date').text(_date);
    }
    if(_day != null){
        $('#day').text(_day);
    }
}

$(document).on("pageload", "#calendarPage", function(e) {
    setGlobalVar(1);
    setStringVar(pYear+".", parseInt(pMonth)+1, "","");
    changeCalendar(pYear,pMonth,pDate);
});

window.setInterval( function() {
    var content = "";
    switch (notif){
        case 1 :
            content = "<div id='notification' >Welcome to YS Joung Company.</div>";
            notif=2;
            break;
        case 2 :
            content = "<div id='notification'>PeriodCalendar : Notifications</div>";
            notif=1;
            break;
    }
    $("#notification").replaceWith(content);
}, 2000 );


$(document).on("pageload", "#introPage", function(e) {
    var today = new Date();
    setGlobalVar(null,today.getFullYear(), today.getMonth(),today.getDate(), today.getDay());
    opacity_bg_layer();
    var introPopUp = "<div id='popup' class='pop_up_layer' style='background:orange;'>" +
        "팝업의 내용입니다. 오늘의 공지사항 입니다." +
        "</div>";
    pop_up_layer(introPopUp);
});

$(document).on("pageload", "#magazinPage", function(e) {

});
$(document).on("pageload", "#mapPage", function(e) {

});
$(document).on("pageload", "#notePage", function(e) {

});
$(document).on("pageload", "#settingPage", function(e) {

});
$(document).on("pageload", "#notifPage", function(e) {

});


